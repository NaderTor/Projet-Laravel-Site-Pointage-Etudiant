<?php $__env->startSection('title','Les utilisateurs enseignant'); ?>

<?php $__env->startSection('contents'); ?>
       <style>
            h3{
                color: white;
            }
       </style>

    <h3>Liste des utilisateurs Enseignant</h3>
    <table>
        <th>ID</th>
        <th>Nom</th>
        <th>Prenom</th>
        <th>Login</th>
        <?php $__currentLoopData = $enseignants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enseignant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($enseignant->type!="admin" && $enseignant->type!="gestionnaire"): ?>
            <tr><td><?php echo e($enseignant->id); ?></td><td><?php echo e($enseignant->nom); ?></td><td><?php echo e($enseignant->prenom); ?></td><td><?php echo e($enseignant->login); ?></td>
            <td><a href="<?php echo e(route('listeCoursEnseignant')); ?>" class="Suppbutton">Liste des cours associé</a></td>
            </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pageacceuil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_Progweb/resources/views/Enseignant/ListeDesEnseignant.blade.php ENDPATH**/ ?>