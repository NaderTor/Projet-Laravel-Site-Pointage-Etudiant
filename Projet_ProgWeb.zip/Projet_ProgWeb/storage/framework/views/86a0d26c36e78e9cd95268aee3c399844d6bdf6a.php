<!------------------------------------------------------------------PAGE PRINCIPALE----------------------------------------------------------------------->
<!DOCTYPE html>
    <html>
        <head>
            <!-- Required meta tags -->
            <meta charset="utf-8" />
            <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>
        </head>

        <body>
    <?php $__env->startSection('menu'); ?>

    
<style>
.MODMDP, .MODNP{
        background-color: blue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }

.ListUser{
    background-color: red;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
}

.ListCours, .ListEtudiants, .ListSeances, .AssoEnse, .AssoEtud{
     background-color: grey;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
}

.CoteEnse{
   background-color: black;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer; 
}

p{
    font-size: large;
    font-weight: bold;
}

a.LG, a.RE, a.LO{
text-decoration: none;
padding: 10px 30px;
background-color: blue; 
color: white;
border: 1px solid gray;
border-style:inset;
}

a.LG3, a.RE3, a.LO3{
    border-radi
us: 12px;
border: 2px solid #46a28d;
}

a.LG:hover, a.RE:hover, a.LO:hover{
    background-color: yellow;
color:red;
}
</style>





<?php if(auth()->guard()->guest()): ?>

    <center>
        <p><Legend>Bienvenue au site de gestion des étudiants</Legend></p>

        <a href="<?php echo e(route('login')); ?>" class="LG LG3">Login</a>
        <a href="<?php echo e(route('register')); ?>" class="RE RE3 ">Enregistrement</a>
    </center
<?php endif; ?>

        <?php $__env->startSection('contents'); ?>
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('logout')); ?>" class="LO LO3">Deconnexion</a>
            <p>Bonjour <?php echo e(Auth::user()->login); ?></p>

            <p>Changer les informations de l'utilisateur connecté:</p>
            <a href = "<?php echo e(route('modifierForm')); ?>" class="MODMDP">Changer le mot de passe</a>
            <a href = "<?php echo e(route('MofifyInfoForm')); ?>" class="MODNP">Modification Nom/Prenom</a>

            <p>Partie Admin:</p>
            <a href = "<?php echo e(route('ListUsers')); ?>" class="ListUser">Liste des utilisateurs</a> 
            
            <p>Partie Admin et Gestionnaire: </p>
            <a href = "<?php echo e(route('listeCours')); ?>" class="ListCours">Voir la liste des cours</a>
            <a href = "<?php echo e(route('listeEtudiants')); ?>" class="ListEtudiants">Voir la liste des étudiants</a>
            <a href = "<?php echo e(route('listeSeance')); ?>" class="ListSeances">Voir la liste des séances</a>
            <a href = "<?php echo e(route('ListeAssociationCourEtudiant')); ?>" class="AssoEtud">Inscription Etudiant-->Cours</a>
            <a href = "<?php echo e(route('ListeCourEnseignant')); ?>" class="AssoEnse">Inscription Enseignant-->Cours</a>

            <p>Partie Admin et Enseignant: </p>
            <a href = "<?php echo e(route('pageEnseignant')); ?>" class="CoteEnse" >Partie Enseignant</a>
        <?php endif; ?>
        <?php $__env->stopSection(); ?>

    <?php echo $__env->yieldSection(); ?>
    <?php $__env->startSection('etat'); ?>
        <?php if(session()->has('etat')): ?>
            <p class="etat"><?php echo e(session()->get('etat')); ?></p>
        <?php endif; ?>
    <?php echo $__env->yieldSection(); ?>
    <?php $__env->startSection('errors'); ?>
        <?php if($errors->any()): ?>
            <div class="error">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php echo $__env->yieldSection(); ?>
        <?php echo $__env->yieldContent('contents'); ?>
    </body>
</html>

    <?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_Progweb/resources/views/Pageacceuil.blade.php ENDPATH**/ ?>