<!------------------------------------------------------PAGE CONTENANT LE FORMULAIRE DE SUPPRESSION D'UN ETUDIANT--------------------------------------->





<?php $__env->startSection('contents'); ?>
<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<form class="bg-light p-3 w-50 m-3" action="<?php echo e(route('deleteEtudiants',['id'=>$etudiants->id])); ?>" method="post">
			<legend> Suppression d'un étudiant </legend>
            <p>Voulez-vous vraiment supprimer <?php echo e($etudiants->prenon); ?> <?php echo e($etudiants->non); ?> ?</p>
        <button type="submit" class="btn btn-primary col-2 mt-4" style="padding:10px; font-size:20px" value="Envoyer" name="oui">OUI</button>
        <button type="submit" class="btn btn-primary col-2 mt-4" style="padding:10px; font-size:20px" value="Envoyer" name="non">NON</button>
        <?php echo csrf_field(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Pageacceuil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_ProgWeb/resources/views/etudiants/DeleteEtudiantsForm.blade.php ENDPATH**/ ?>