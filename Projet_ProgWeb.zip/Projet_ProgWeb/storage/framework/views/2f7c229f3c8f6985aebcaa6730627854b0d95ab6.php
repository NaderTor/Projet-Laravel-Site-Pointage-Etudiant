<!------------------------------------------------------PAGE CONTENANT LA LISTE DES ASSOCIATIONS ENSEIGNANT/COURS--------------------------------->





<?php $__env->startSection('contents'); ?>

<style>
table,
    th,
    td {
        padding: 9px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }
    .AjouAssoEns{
        background-color: blue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }

      .SuppAssoEns{
        background-color: red;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      .retour{
     background-color: green;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
}
</style>

<table>
        <th>Cours_Id</th>
        <th>User_ID</th>

<?php $__currentLoopData = $associations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $association): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><td> <?php echo e($association->cours_id); ?></td> <td> <?php echo e($association->user_id); ?></td><td>
<a href="<?php echo e(route('dissociateEnseignantForm', ['cours_id' => $association->cours_id , 'user_id' => $association->user_id])); ?>" class="SuppAssoEns">supprimer une association</a></td>
</tr>
   
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table> 
        <center>
            <p><a href="<?php echo e(route('associationEnseignantForm')); ?>" class="AjouAssoEns">Ajouter une association </a></p>
            <p><a href="<?php echo e(route('pageacceuil')); ?>" class="retour">Retourner à l'acceuil</a></p>
            <p>Allez dans la liste des cours puis dans "Liste Enseignant associé" pour voir que l'association à été effectuer</p>
        </center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pageacceuil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_ProgWeb/resources/views/InscriptionEnseignant/ListeAssociationEnseignant.blade.php ENDPATH**/ ?>