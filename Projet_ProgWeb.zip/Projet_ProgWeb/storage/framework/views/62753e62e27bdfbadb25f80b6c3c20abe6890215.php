<!------------------------------------------------------PAGE CONTENANT LA LISTE DE TOUS LES UTILISATEURS--------------------------------------------------->




<?php $__env->startSection('title','Liste des Utilisateurs'); ?>

<?php $__env->startSection('contents'); ?>
    <center><legend>Liste des utilisateurs</legend></center>
    <a href="<?php echo e(route('pageacceuil')); ?>"><button name="acceuil"><span>Retour à l'accueil</span></button></a>
    <style>
    
       table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }
      button {
        display: inline-block;
        background-color: #7b38d8;
        border-radius: 10px;
        border: 4px double #cccccc;
        color: #eeeeee;
        text-align: center;
        font-size: 15px;
        padding: 10px;
        width: 150px;
        transition: all 0.5s;
        cursor: pointer;
        margin: 5px;
        margin-left:auto;
        margin-right:auto;
      }
      button span {
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;
      }
      button span:after {
        content: "\00bb";
        position: absolute;
        opacity: 0;
        top: 0;
        right: -20px;
        transition: 0.5s;
      }
      button:hover {
        background-color: #f7c2f9;
      }
      button:hover span {
        padding-right: 5px;
      }
      button:hover span:after {
        opacity: 1;
        right: 0;
      }
    </style>
    
    <table>
        <th>Id</th>
        <th>Nom</th>
        <th>Penom</th>
        <th>Login</th>
        <th>Type</th>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($user->id); ?></td>
            <td><?php echo e($user->nom); ?></td>
            <td><?php echo e($user->prenom); ?></td>
            <td><?php echo e($user->login); ?></td>
            <td><?php echo e($user->type); ?></td>
            <td><a href="<?php echo e(route('DeleteFormUser',['id'=>$user->id])); ?>"><button class = 'suppUser'> <span>Supprimer </span></button></a></td>
            <td><a href = "<?php echo e(route('MofifyTypeForm',['id'=>$user->id])); ?>"><button class = 'acceptUser'><span>Acceptation</span></button></a></td>
            <td><a href = "<?php echo e(route('ModifyUserForm',['id'=>$user->id])); ?>"><button class = "modUser"> <span>Modifier l'utilisateur </span></button></a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <center>
        <a href="<?php echo e(route('CreateEnseignantForm')); ?>"><button class="creeEns"><span>Créer un utilisateur enseignant</span></button>
        <a href="<?php echo e(route('CreateGestionnaireForm')); ?>"><button class="creeGes"><span>Créer un utilisateur gestionnaire</span></button>
        <a href="<?php echo e(route('ListUtilisateurGestionnaire')); ?>"><button class="voirGes"><span>Voir les utilisateurs gestionnaire</span></button>        <a href="<?php echo e(route('CreateGestionnaireForm')); ?>"><button class="creeGes"><span>Créer un utilisateur gestionnaire</span></button>
        <a href="<?php echo e(route('ListUtilisateurEnseignant')); ?>"><button class="voirEns"><span>Voir les utilisateurs enseignant</span></button>
        </center>

        </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pageacceuil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_ProgWeb/resources/views/user/usersListe.blade.php ENDPATH**/ ?>