<!------------------------------------------------------PAGE CONTENANT LA LISTE DES SEANCES DE CHAQUE COURS-------_----------------------------->





<?php $__env->startSection('contents'); ?>

<center>
<Legend>Liste des Séances pour ce cours</Legend>
</center>

<style>
    
       table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }

    
      
      .retour {
        background-color: green;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      .point {
        background-color: lightblue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }

      .ListPre {
        background-color: lightgrey;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
    
      
      
</style>


<table>
        <th>Id</th>
        <th>Cours_ID</th>
        <th>Date de début</th>
        <th>Date de fin</th>
        

<?php $__currentLoopData = $seances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><td> <?php echo e($seance->id); ?></td> <td> <?php echo e($seance->cours_id); ?></td> <td><?php echo e($seance->date_debut); ?></td> <td><?php echo e($seance->date_fin); ?></td><td>
    <a href = <?php echo e(route('pointageForm',['seance_id'=>$seance->id])); ?> class="point">Effectuer le pointage</a></td>
    <td><a href = <?php echo e(route('listePresence',['seance_id'=>$seance->id])); ?> class="ListPre">Liste Des présents</a></td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table> 
        <center>
            <p><a href="<?php echo e(route('listeCoursEnseignant')); ?>" class="retour">Retourner à la liste des cours de l'Enseignant</a></p>
            <p><a href="<?php echo e(route('pageEnseignant')); ?>" class="retour">Retourner à la page des enseignant</a></p>
        </center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pageacceuil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_Progweb/resources/views/Enseignant/ListeSeanceParCours.blade.php ENDPATH**/ ?>