<!------------------------------------------------------PAGE CONTENANT LA LISTE DES ETUDIANT--------------------------------------------------->




<?php $__env->startSection('contents'); ?>

<style>
   table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }

    .SuppEtu {
        background-color: red;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }

      .ModEtu {
        background-color: yellow;
        border: none;
        color: black;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      .Ajouetu {
        background-color: blue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      .retour {
        background-color: green;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      
</style>
<table>
        <th>Id</th>
        <th>Nom</th>
        <th>Prenom</th>
        <th>N°étudiant</th>
        <th>Created_at</th>
        <th>Updated_at</th>

<?php $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><td> <?php echo e($etudiant->id); ?></td> <td> <?php echo e($etudiant->nom); ?></td> <td><?php echo e($etudiant->prenom); ?></td> <td><?php echo e($etudiant->noet); ?></td><td><?php echo e($etudiant->created_at); ?></td><td><?php echo e($etudiant->updated_at); ?></td><td>
    <a href="<?php echo e(route('deleteEtudiantsForm', ['id'=>$etudiant->id])); ?>" class="SuppEtu">Supprimer un etudiant</a></td><td>
    <a href="<?php echo e(route('modifyEtudiantsForm', ['id'=>$etudiant->id])); ?>" class="ModEtu">Modifier un étudiant</a></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table> 
        <center>
            <p><a href="<?php echo e(route('createEtudiantsForm')); ?>" class="Ajouetu">Ajouter un étudiant</a></p>
            <p><a href="<?php echo e(route('pageacceuil')); ?>" class="retour">Retourner à l'acceuil</a></p>
        </center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pageacceuil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_ProgWeb/resources/views/etudiants/ListeDesEtudiants.blade.php ENDPATH**/ ?>