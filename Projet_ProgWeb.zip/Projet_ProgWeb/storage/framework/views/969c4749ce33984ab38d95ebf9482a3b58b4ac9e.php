<?php $__env->startSection('title','Les Utilisateurs Enseignant'); ?>

<?php $__env->startSection('contents'); ?>

    <style>
    table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }     
    </style>

    <h3>Liste des utilisateurs ENSEIGNANT</h3>
    <table>
        <th>ID</th>
        <th>Nom</th>
        <th>Prenom</th>
        <th>Login</th>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user ->type!="admin" && $user ->type!="gestionnaire"): ?>
                <tr>
                    <td><?php echo e($user->id); ?></td><td><?php echo e($user->nom); ?></td><td><?php echo e($user->prenom); ?></td><td><?php echo e($user->login); ?></td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pageacceuil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_Progweb/resources/views/user/EnseignantListe.blade.php ENDPATH**/ ?>