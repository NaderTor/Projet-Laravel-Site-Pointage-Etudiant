<!------------------------------------------------------PAGE DE LA SUPPRESSION D'UNE ASSOCIATION D'UN ETUDIANT A UN COOURS--------------------------------->





<?php $__env->startSection('title','Dissocier des etudiants'); ?>

<?php $__env->startSection('contents'); ?>
    <p>Voulez-vous supprimer cette inscrption ?</p>
    <form action="<?php echo e(route('dissociateEtudiant',  ['cours_id' => $cours_id , 'etudiant_id' => $etudiant_id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="submit" value="Supprimer">
        <button style="padding-left: 10px;margin-top: 5px;"><a href="<?php echo e(route('ListeAssociationCourEtudiant')); ?>" type="submit"
         value="Annuler" style="color: black ;text-decoration: none;width: 70px">Annuler</a></button>

    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('PageAcceuil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_ProgWeb/resources/views/AssociationEtudiantCour/DissociateEtudiantForm.blade.php ENDPATH**/ ?>