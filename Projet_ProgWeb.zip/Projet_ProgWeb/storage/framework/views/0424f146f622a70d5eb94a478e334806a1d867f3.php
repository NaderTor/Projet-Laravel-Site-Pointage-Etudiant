<!------------------------------------------------------PAGE CONTENANT LA PARTIE DES TACHE DES ENSEIGNANTS--------------------------------->




<?php $__env->startSection('contents'); ?>

<style>
.ListCourIns {
        background-color: lightpink;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      .acceuil {
        background-color: lightgreen;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }

</style>
 <p><a href = "<?php echo e(route('listeCoursEnseignant')); ?>" class="ListCourIns">Liste des cours inscrit</a></p>
 <p><a href = "<?php echo e(route('pageacceuil')); ?>" class="acceuil">Retourner à la l'accueil</a></p>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('pageacceuil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_ProgWeb/resources/views/Enseignant/PageEnseignant.blade.php ENDPATH**/ ?>