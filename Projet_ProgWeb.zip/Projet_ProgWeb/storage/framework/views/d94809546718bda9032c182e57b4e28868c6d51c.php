<!------------------------------------------------------PAGE CONTENANT LA LISTE DES COURS--------------------------------------------------->




<?php $__env->startSection('contents'); ?>

<style>
    
       table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }
      .Suppbutton {
        background-color: red;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
    .Modbutton {
        background-color: yellow;
        border: none;
        color: black;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }


.Ajoubutton {
        background-color: blue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
}

.ListeEtu{
    background-color: grey;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
}

.ListeEns{
    background-color: black;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
}
.retour{
     background-color: green;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
}
    </style>
<table>
        <th>Id</th>
        <th>Intitulé</th>
        <th>Created_at</th>
        <th>Updated_at</th>

<?php $__currentLoopData = $cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><td> <?php echo e($cour->id); ?></td> <td> <?php echo e($cour->intitule); ?></td> <td><?php echo e($cour->created_at); ?></td> <td> <?php echo e($cour->updated_at); ?></td><td>
    <a href="<?php echo e(route('deleteCoursForm', ['id'=>$cour->id])); ?>" class="Suppbutton">Supprimer</a></td><td>
    <a href="<?php echo e(route('modifyCoursForm', ['id'=>$cour->id])); ?>" class="Modbutton">Modifier le cour</a></td><td>
    <a href="<?php echo e(route('listeCoursEtudiant', ['id'=>$cour->id])); ?>" class="ListeEtu">Liste étudiants associé</a></td><td>
    <a href="<?php echo e(route('listecoursEnseignant', ['id'=>$cour->id])); ?>" class="ListeEns">Liste enseignant associé</a></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table> 
        <center>
            <p><a href="<?php echo e(route('createCoursForm')); ?>" class="Ajoubutton">Créer un cours</a></p>
            <p><a href="<?php echo e(route('pageacceuil')); ?>" class="retour">Retourner à l'acceuil</a></p>
        </center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pageacceuil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_ProgWeb/resources/views/cours/ListeDesCours.blade.php ENDPATH**/ ?>