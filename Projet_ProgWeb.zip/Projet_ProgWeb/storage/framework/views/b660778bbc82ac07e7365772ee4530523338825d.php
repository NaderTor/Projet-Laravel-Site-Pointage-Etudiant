<!------------------------------------------------------PAGE CONTENANT LE FORMULAIRE DE POINTAGE DES ETUDIANTS A UN COURS --------------------------------->





<?php $__env->startSection('contents'); ?>

<style>

    
      .retour {
        background-color: green;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      
</style>
<table>
<form action=<?php echo e(route('pointage',['seance_id'=>$seance->id])); ?> method="post">
    <?php $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<input type="checkbox" name="pointage[]" value=<?php echo e($etudiant->id); ?>>
<label> <?php echo e($etudiant->id); ?><?php echo e($etudiant->nom); ?><?php echo e($etudiant->prenom); ?><?php echo e($etudiant->noet); ?><?php echo e($etudiant->created_at); ?><?php echo e($etudiant->updated_at); ?></label>
<br>   
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <input type="submit" value="valider">
    <?php echo csrf_field(); ?>
</form>
</table>
        <center>  
            <p><a href="<?php echo e(route('listeCoursEnseignant')); ?>" class="retour">Retourner à la liste des cours de l'Enseignant</a></p>
            <a href="<?php echo e(route('pageEnseignant')); ?>" class="retour">Retourner à la page des enseignant</a>
        </center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pageacceuil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_Progweb/resources/views/Enseignant/PointageForm.blade.php ENDPATH**/ ?>