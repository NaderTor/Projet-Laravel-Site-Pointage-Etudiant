<!------------------------------------------------------PAGE CONTENANT LE FORMULAIRE DE MODIFICATION NOM/PRENOM D'UN UTILISATEUR--------------------------------------->




<?php $__env->startSection('title','Modification informations'); ?>

<?php $__env->startSection('contents'); ?>
<center>
    <meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<form class="bg-light p-3 w-50 m-3" action="<?php echo e(route('ModifyInfo')); ?>" method="post">
			<legend>Vous pouvez modifier les informations de <?php echo e($user->login); ?>.</legend>
			<div class="form-group row mb-0">
                <center>
				<label for="inputNom" class="col-6 col-form-label"> Nom </label>
                </center>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="nom" value="<?php echo e($user->nom); ?>">
				</div>
			</div>
			<div class="form-group row mb-0">
                <center>
				<label for="inputNom" class="col-6 col-form-label"> Prénom </label>
                </center>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="prenom" value="<?php echo e($user->prenom); ?>">
				</div>
			</div>
        <button type="submit" class="btn btn-primary col-4 mt-3" style="padding:10px; font-size:20px" value="Envoyer">Envoyer</button>
      <button style="padding-left: 10px;margin-top: 5px;"><a href="<?php echo e(route('pageacceuil')); ?>" type="submit"
         value="Annuler" style="color: black ;text-decoration: none;width: 70px">Annuler</a></button>
        <?php echo csrf_field(); ?>
</form>
</center>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('PageAcceuil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_Progweb/resources/views/user/modifyinfoForm.blade.php ENDPATH**/ ?>