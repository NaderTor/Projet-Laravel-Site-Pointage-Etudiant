<!------------------------------------------------------PAGE CONTENANT LE FORMULAIRE DE SUPPRESSION D'UN COURS--------------------------------------->





<?php $__env->startSection('contents'); ?>
<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<form class="bg-light p-3 w-50 m-3" action="<?php echo e(route('deleteCours',['id'=>$cours->id])); ?>" method="post">
			<legend> Suppression d'un cour </legend>
            <p>Voulez-vous vraiment supprimer le cour <?php echo e($cours->intitule); ?> ?</p>
        <button type="submit" class="btn btn-primary col-2 mt-4" style="padding:10px; font-size:20px" value="Envoyer" name="oui">OUI</button>
        <button type="submit" class="btn btn-primary col-2 mt-4" style="padding:10px; font-size:20px" value="Envoyer" name="non">NON</button>
        <?php echo csrf_field(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Pageacceuil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_Progweb/resources/views/cours/DeleteCoursForm.blade.php ENDPATH**/ ?>