<!------------------------------------------------------PAGE CONTENANT LE FORMULAIRE DE MODIFICATION D'UN UTILISATEUR--------------------------------------->




<?php $__env->startSection('contents'); ?>
   
<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<form class="bg-light p-3 w-50 m-3" action="<?php echo e(route('ModifyUser',['id'=>$user->id])); ?>" method="post">
			<legend> Vous pouvez modifier cet utilisateur </legend>
			<div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Nom </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="nom" value="<?php echo e($user->nom); ?>">
				</div>
			</div>
			<div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Prénom </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="prenom" value="<?php echo e($user->prenom); ?>">
				</div>
			</div>
			<div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Login </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="login" value="<?php echo e($user->login); ?>">
				</div>
			</div>
            <div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Mot-De-Passe </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="password" class="form-control" id="inputNom" style="width:93.5%" name="mdp" value = "">
				</div>
			</div>
            <div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Confirmation du Mot-De-Passe </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="password" class="form-control" id="inputNom" style="width:93.5%" name="mdp_confirmation">
				</div>
			</div>
        <div class="champ">
				<label for="type" class="col-1 col-form-label"> Type: </label>
                <select id="type" name="type" value="<?php echo e($user->type); ?>">
                <optgroup label="Type">
                    <option value="enseignant">Enseignant</option>
                    <option value="gestionnaire">Gestionnaire</option>
                    </select>
			</div>
        <button type="submit" class="btn btn-primary col-2 mt-3" style="padding:5px; font-size:20px" name="envoyer" value="Envoyer">Envoyer</button>
        <button style="padding:5px; font-size:20px" class="btn btn-primary col-2 mt-3" ><a href="<?php echo e(route('ListUsers')); ?>" type="submit" value="Annuler" style="color: black ;text-decoration: none;width: 70px">Annuler</a></button>
        <?php echo csrf_field(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('PageAcceuil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadertorjemane/Stock_MAMP/Projet_Progweb/resources/views/user/modifyUserForm.blade.php ENDPATH**/ ?>