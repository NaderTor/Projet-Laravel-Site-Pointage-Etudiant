<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthenticatedController;
use App\Http\Controllers\RegisterUserController;
use App\Http\Controllers\Admin;
use App\Http\Controllers\CoursController;
use App\Http\Controllers\EtudiantController;
use App\Http\Controllers\SeancesController;
use App\Http\Controllers\AssociationCourEtudiant;
use App\Http\Controllers\AssociationCourEnseignant;
use App\Http\Controllers\EnseignantController;



/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('PageAcceuil');     //Route qui mène à la page d'acceuil
})->name('pageacceuil');

Route::get('/login', [AuthenticatedController::class,'create'])->name('login');//Route qui mène au formulaire de connexion 

Route::post('/login', [AuthenticatedController::class,'store']);                //Route qui mène à la fonction qui permet l'authentification

Route::get('/logout', [AuthenticatedController::class,'destroy'])->name('logout')->middleware('auth');//Route qui mène à la fonction qui permet la deconnexion

Route::get('/register', [RegisterUserController::class,'create'])->name('register');//Route qui mene au formulaire de creation d'un compte

Route::post('/register', [RegisterUserController::class,'store']);//Route qui mene à la fonction qui permet la creation d'un compte

Route::get('/modifier',[AuthenticatedController::class, 'ModifierForm'])->name('modifierForm'); //Route qui mene au formaulaire de changement du MDP
Route::post('/modifier',[AuthenticatedController::class, 'Modifier'])->name('modifier');        //Route qui mene à la fonction qui change le MDP



Route::get('/Utilisateur',[Admin::class, 'listUtilisateur'])->name('ListUsers')->middleware('is_admin');//Route qui mene à la liste des utilsateurs

Route::get('/UtilisateurEnseignant',[Admin::class, 'listUtilisateurEnseignant'])->name('ListUtilisateurEnseignant')->middleware('is_admin');//Route qui mene à la liste des utilsateurs enseignant

Route::get('/UtilisateurGestionnaire',[Admin::class, 'listUtilisateurGestionnaire'])->name('ListUtilisateurGestionnaire')->middleware('is_admin');//Route qui mene à la liste des utilsateurs gestionnaire

Route::get('/creationEnseignant',[Admin::class,'creationEnseignantForm'])->name('CreateEnseignantForm');//Route qui mene au formulaire de creation d'un utilsateur enseignant
Route::post('/creationEnseignant',[Admin::class,'creationEnseignant'])->name('CreationEnseignant');//Route qui mene a la fonction qui permet la creation d'un utilsateur enseignant

Route::get('/creationGestionnaire',[Admin::class,'creationGestionnaireForm'])->name('CreateGestionnaireForm');//Route qui mene au formulaire de creation d'un utilsateur gestionnaire
Route::post('/creationGestionnaire',[Admin::class,'creationGestionnaire'])->name('CreationGestionnaire');//Route qui mene a la fonction qui permet la creation d'un utilsateur gestionnaire

Route::get('/supprimeruser/{id}',[Admin::class,'deleteFormUser'])->name('DeleteFormUser')->middleware('is_admin');//Route qui mene au formulaire de suppression d'un utilsateur 
Route::post('/supprimeruser/{id}',[Admin::class,'delete'])->name('Delete')->middleware('is_admin');//Route qui mene a la fonction qui permet la suppression d'un utilsateur 

Route::get('/modifieruser/{id}',[Admin::class,'modifyTypeForm'])->name('MofifyTypeForm')->middleware('is_admin');//Route qui mene au formulaire de modification du type d'un utilsateur 
Route::post('/modifieruser/{id}',[Admin::class,'modifyType'])->name('ModifyType')->middleware('is_admin');//Route qui mene a la fonction qui permet la modification du type d'un utilsateur 

Route::get('/modifierinfo',[Admin::class,'modifyInfoForm'])->name('MofifyInfoForm');//Route qui mene au formulaire de modification du Nom/prenom d'un utilsateur 
Route::post('/modifierinfo',[Admin::class,'modifyInfo'])->name('ModifyInfo');//Route qui mene a la fonction qui permet la modification du nom/prenom d'un utilsateur 

Route::get('/modifierUser/{id}',[Admin::class,'modifyUserForm'])->name('ModifyUserForm');//Route qui mene au formulaire de modification des infos d'un utilsateur 
Route::post('/modifierUser/{id}',[Admin::class,'modifyUser'])->name('ModifyUser');//Route qui mene a la fonction qui permet la modification des infos d'un utilsateur




Route::get('/ListeCours',[CoursController::class,'ListeCours'])->name('listeCours')->middleware('is_not_enseignant');//Route qui mene à la liste des cours

Route::get('/creationCour',[CoursController::class,'CreateCoursForm'])->name('createCoursForm')->middleware('is_admin');//Route qui mene au formulaire de creation d'un cours 
Route::post('/creationCour',[CoursController::class,'CreateCours'])->name('createCours')->middleware('is_admin');//Route qui mene a la fonction qui permet la creation d'un cours

Route::get('/suppressionCour/{id}',[CoursController::class,'DeleteCoursForm'])->name('deleteCoursForm')->middleware('is_admin');//Route qui mene au formulaire de suppression d'un cours
Route::post('/suppressionCour/{id}',[CoursController::class,'DeleteCours'])->name('deleteCours')->middleware('is_admin');//Route qui mene a la fonction qui permet la suppression d'un cours

Route::get('/modificationCour/{id}',[CoursController::class,'ModifyCoursForm'])->name('modifyCoursForm')->middleware('is_admin');//Route qui mene au formulaire de modification d'un cours 
Route::post('/modificationCour/{id}',[CoursController::class,'ModifyCours'])->name('modifyCours')->middleware('is_admin');//Route qui mene a la fonction qui permet la modification d'un cours 

Route::get('/listeEtudiantassocie',[AssociationCourEtudiant::class,'EtudiantInscrit'])->name('listeCoursEtudiant')->middleware('is_not_enseignant');//Route qui mene à la liste des etudiants inscrit à un cours

Route::get('/listeEnseignantassocie',[AssociationCourEnseignant::class,'EnseignantInscrit'])->name('listecoursEnseignant')->middleware('is_not_enseignant');//Route qui mene à la liste des enseignant inscrit à un cours





Route::get('/ListeEtudiants',[EtudiantController::class,'ListeEtudiant'])->name('listeEtudiants')->middleware('is_not_enseignant');//Route qui mene à la liste des etudiants

Route::get('/creationEtudiant',[EtudiantController::class,'CreateEtudiantsForm'])->name('createEtudiantsForm')->middleware('is_not_enseignant');//Route qui mene au formulaire de creation d'un etudiant 
Route::post('/creationEtudiant',[EtudiantController::class,'CreateEtudiants'])->name('createEtudiants')->middleware('is_not_enseignant');//Route qui mene a la fonction qui permet la creation d'un etudiant

Route::get('/suppressionEtudiant/{id}',[EtudiantController::class,'DeleteEtudiantsForm'])->name('deleteEtudiantsForm')->middleware('is_not_enseignant');//Route qui mene au formulaire de suppression d'un etudiant
Route::post('/suppressionEtudiant/{id}',[EtudiantController::class,'DeleteEtudiants'])->name('deleteEtudiants')->middleware('is_not_enseignant');//Route qui mene a la fonction qui permet la suppression d'un etudiant

Route::get('/modificationEtudiant/{id}',[EtudiantController::class,'ModifyEtudiantsForm'])->name('modifyEtudiantsForm')->middleware('is_not_enseignant');//Route qui mene au formulaire de modification d'un etudiant 
Route::post('/modificationEtudiant/{id}',[EtudiantController::class,'ModifyEtudiants'])->name('modifyEtudiants')->middleware('is_not_enseignant');//Route qui mene a la fonction qui permet la modification d'un etudiant




Route::get('/ListeSeances',[SeancesController::class,'ListeSeance'])->name('listeSeance')->middleware('is_not_enseignant');//Route qui mene à la liste des seances

Route::get('/creationSeance',[SeancesController::class,'CreateSeancesForm'])->name('createSeancesForm')->middleware('is_not_enseignant');//Route qui mene au formulaire de creation d'une seance 
Route::post('/creationSeance',[SeancesController::class,'CreateSeances'])->name('createSeances')->middleware('is_not_enseignant');//Route qui mene a la fonction qui permet la creation d'un seance

Route::get('/suppressionSeance/{id}',[SeancesController::class,'DeleteSeancesForm'])->name('deleteSeancesForm')->middleware('is_not_enseignant');//Route qui mene au formulaire de suppression d'une seance
Route::post('/suppressionSeance/{id}',[SeancesController::class,'DeleteSeances'])->name('deleteSeances')->middleware('is_not_enseignant');//Route qui mene a la fonction qui permet la suppression d'une seance

Route::get('/modificationSeance/{id}',[SeancesController::class,'ModifySeancesForm'])->name('modifySeancesForm')->middleware('is_not_enseignant');//Route qui mene au formulaire de modification d'une seance 
Route::post('/modificationSeance/{id}',[SeancesController::class,'ModifySeances'])->name('modifySeances')->middleware('is_not_enseignant');//Route qui mene a la fonction qui permet la modification d'une seance




Route::get('/ListeAssociationEtudiant',[AssociationCourEtudiant::class,'listeAssociationCourEtudiant'])->name('ListeAssociationCourEtudiant')->middleware('is_not_enseignant');//Route qui mene à la liste des association Cour/etudiant

Route::get('/creationAssociationEtudiant',[AssociationCourEtudiant::class,'AssociationEtudiantForm'])->name('associationEtudiantForm')->middleware('is_not_enseignant');//Route qui mene au formulaire de creation d'une association Cour/etudiant
Route::post('/creationAssociationEtudiant',[AssociationCourEtudiant::class,'AssociationEtudiant'])->name('associationEtudiant')->middleware('is_not_enseignant');//Route qui mene a la fonction qui permet la creation d'une association Cour/etudiant

Route::get('/suppressionAssociationEnseignant/{cours_id}/{etudiant_id}',[AssociationCourEtudiant::class,'DissociateEtudiantForm'])->name('dissociateEtudiantForm')->middleware('is_not_enseignant');//Route qui mene au formulaire de suppression d'une association Cour/etudiant
Route::post('/suppressionAssociationEnseignant/{cours_id}/{etudiant_id}',[AssociationCourEtudiant::class,'DissociateEtudiant'])->name('dissociateEtudiant')->middleware('is_not_enseignant');//Route qui mene a la fonction qui permet la suppression d'une association Cour/etudiant



Route::get('/ListeAssociationEnseignant',[AssociationCourEnseignant::class,'listeCourEnseignant'])->name('ListeCoursEnseignant')->middleware('is_not_enseignant');//Route qui mene à la liste des association Cour/enseignant

Route::get('/creationAssociationEnseignant',[AssociationCourEnseignant::class,'AssociationEnseignantForm'])->name('associationEnseignantForm')->middleware('is_not_enseignant');//Route qui mene au formulaire de creation d'une association Cour/enseignant
Route::post('/creationAssociationEnseignant',[AssociationCourEnseignant::class,'AssociationEnseignant'])->name('AssociationEnseignant')->middleware('is_not_enseignant');//Route qui mene a la fonction qui permet la creation d'une association Cour/enseignant

Route::get('/suppressionAssociationEnseignant/{cours_id}/{user_id}',[AssociationCourEnseignant::class,'DissociateEnseignantForm'])->name('dissociateEnseignantForm')->middleware('is_not_enseignant');//Route qui mene au formulaire de suppression d'une association Cour/enseignant
Route::post('/suppressionAssociationEnseignant/{cours_id}/{user_id}',[AssociationCourEnseignant::class,'DissociateEnseignant'])->name('dissociateEnseignant')->middleware('is_not_enseignant');//Route qui mene a la fonction qui permet la suppression d'une association Cour/enseignant




Route::get('/PageEnseignant', function () {
    return view('Enseignant.PageEnseignant');                   //Route qui mene à la page des enseignant
})->name('pageEnseignant')->middleware('is_not_gestionnaire');

Route::get('/listeDesEnseignant',[EnseignantController::class,'ListeDesEnseignant'])->name('listeDesEnseignant')->middleware('is_not_gestionnaire');

Route::get('/listeDesCoursEnseignant',[EnseignantController::class,'ListeCoursEnseignant'])->name('listeCoursEnseignant')->middleware('is_not_gestionnaire');//route qui mene à la cours des cours pour chaque enseignant

Route::get('/ListeSeanceByCours',[EnseignantController::class,'ListeSeanceByCours'])->name('listeSeanceByCours');//Route qui mene à la liste des seance par cours associé à l'enseignant

Route::get('/PointageEtudiant',[EnseignantController::class,'PointageForm'])->name('pointageForm')->middleware('is_not_gestionnaire');//Route qui mene au formulaire de creation d'une association Cour/enseignant
Route::post('/PointageEtudiant',[EnseignantController::class,'Pointage'])->name('pointage')->middleware('is_not_gestionnaire');//Route qui mene a la fonction qui permet la creation d'une association Cour/enseignant

Route::get('/ListedesPresencesParSeance',[EnseignantController::class,'ListePresence'])->name('listePresence');//Route qui mène à la liste des etudiant pointe pour la seance
