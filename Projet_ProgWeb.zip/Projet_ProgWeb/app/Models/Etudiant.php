<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Etudiant extends Model {
    public $timestamps = true;
    use HasFactory;
    protected $table = "etudiants";

    function cours(){
        return $this->belongsToMany(Cour::class, 'cours_etudiants', 'etudiant_id', 'cours_id');
        }


        function seances(){
            return $this->belongsToMany(Seance::class, 'presences', 'etudiant_id', 'seance_id');
            }
}