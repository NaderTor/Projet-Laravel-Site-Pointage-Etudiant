<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class Cour extends Model {
    use HasFactory;
    public $timestamps = true;
    

    function seances() {
        return $this->hasMany(Seance::class, 'cours_id');
    }

    function etudiants(){
        return $this->belongsToMany(Etudiant::class, 'cours_etudiants', 'cours_id', 'etudiant_id');
    }

    function enseignant(){
        return $this->belongsToMany(User::class, 'cours_users', 'cours_id', 'user_id');
    }
}