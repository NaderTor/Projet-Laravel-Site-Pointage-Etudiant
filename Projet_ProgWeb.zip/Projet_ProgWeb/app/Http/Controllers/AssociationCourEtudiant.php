<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Cour;
use App\Models\Etudiant;


class AssociationCourEtudiant extends Controller
{
    //fonction qui renvoie la liste des associations Cours/etudiant
    public function listeAssociationCourEtudiant(){
        $associations = DB::table('cours_etudiants')->get();
        return view('AssociationEtudiantCour.ListeAssociationEtudiant',['associations'=>$associations]);
    }

     //fonction qui renvoie la liste des etudiant inscrit à un cours
    public function EtudiantInscrit(Request $request){
        $c = Cour::where('id',$request->id)->first();
        $etudiants = $c->etudiants()->get();
        return view('cours.ListeEtudiantsInscrit',['associations'=>$etudiants]);
    }

    //fonction qui renvoie le formulaire des associations Cours/etudiant
    public function AssociationEtudiantForm() {
        return view('AssociationEtudiantCour.CreateAssociationForm');
    }

    //fonction qui associe un etudiant à un cours
    public function AssociationEtudiant(Request $request){
        $validated = $request->validate([
            'cours' => 'bail|required|alpha',
            'etudiant' => 'bail|required|alpha',
        ]);

        $etudiants = Etudiant::where('nom',$request->etudiant)->first();
        $cours = Cour::where('intitule',$request->cours)->first();
        if(isset($cours->id)){
            
            $cours->cours_id = $cours->id;
            $etudiants->etudiant_id = $etudiants->id;
            $etudiants->cours()->attach($cours);
            

        $request->session()->flash('etat', 'Association effectuée !');
        return redirect()->route('ListeAssociationCourEtudiant');

    }
    return back()->withErrors(['association'=>"Une des deux informations entrée dans les champs n'existe pas "]);
}
//fonction qui renvoie le formulaire de dissociation Cours/etudiant
public function DissociateEtudiantForm($cours_id,$etudiant_id) {
    return view('AssociationEtudiantCour.DissociateEtudiantForm', ['cours_id' => $cours_id, 'etudiant_id' => $etudiant_id]);
}
//fonction qui dissocie un etudiant à un cours
public function DissociateEtudiant(Request $request,$cours_id,$etudiant_id){
    $etudiants = Etudiant::findOrFail($etudiant_id);
    $cours = Cour::findOrFail($cours_id);


    $etudiants->cours()->detach($cours);
    
    $request->session()->flash('etat', 'Dissociation effectuée !');
    return redirect()->route('ListeAssociationCourEtudiant');

}


}


