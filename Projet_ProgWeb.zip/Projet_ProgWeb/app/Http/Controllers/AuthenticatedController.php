<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;



class AuthenticatedController extends Controller
{
    //fonction qui renvoie le formulaire d'authentification
    public function create(){
        return view('auth.login');
    }


    // fonction qui permet l'authentification
    public function store(Request $request){

        $request->validate([
            'login' => 'required|string',
            'mdp' => 'required|max:40'
            ]);

            $user = User::where('login',$request->login)->first();

            if ($user->type == NULL){
                return view('pageacceuil')->withErrors([
                    'type' => 'Le gérant ne vous a pas encore acceptez, veuillez patientez svp' ,
                ]);
            }

        $credentials = ['login' => $request->input('login'), 'password' => $request->input('mdp')];
        
        
        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();

            $request->session()->flash('etat','Login successful');

            return redirect()->route('pageacceuil');
        }
        return back()->withErrors([
            'login' => 'The provided credentials do not match our records.',
        ]);
    }


     // fonction qui permet la deconnexion
    public function destroy(Request $request){
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();


        return view("PageAcceuil");
    }

    // fonction qui renvoie le formulaire de changement de MDP
    public function Modifierform(){
        $users = AUTH::user();
        return view('auth.modifierform', ['u'=>$users]);
    }
    // fonction qui permet le changement de MDP
    public function Modifier(Request $request){
        $users = AUTH::user();
        
        $validated = $request->validate([
            'mdp' => 'required|string|confirmed',
            ]);                                                
            $users->mdp = Hash::make($request->mdp);                                         
                                            

        $users->save();
        $request->session()->flash('etat', 'Modification effectuée !');         
        return redirect()->route('pageacceuil');
    
    }

}
