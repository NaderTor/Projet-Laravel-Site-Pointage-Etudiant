<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Cour;



class CoursController extends Controller
{
    public function ListeCours(){
        $cours = DB::table('cours')->get();
        return view('cours.ListeDesCours',['cours'=>$cours]);
    }


    public function CreateCoursForm() {//=================>                          //Ajouter un cours dans la table "cours"
        return view('cours.CreateCoursForm');
    }

    public function CreateCours(Request $request) {
        $validated = $request->validate([ //=========>                          //On applique les règles de validation vue en cours                 
        'intitule' => 'required|alpha|max:40',                       
        
        ]);
    
        $cours = new Cour();//========================>                           //On crée un nouveau cours
        $cours->intitule = $validated['intitule'];
        

        $cours->save();//============================>                           //On l'enregistre

        $request->session()->flash('etat', 'Cours créer !');//=====>        //On ajoute un message flash si la création à été effectué

        return redirect()->route('listeCours');//============>                   //Après cela, on revient a la liste contenant tous les noms
    }

    public function DeleteCoursForm($id) {//============>                            //Supprimer un cours dans la table "cours"
        $cours = Cour::findOrFail($id);//=============>                            //On recherche le cours avec son ID
        return view('cours.DeleteCoursForm', ['cours'=>$cours]);
    }

    public function DeleteCours(Request $request,$id) {
        $cours = Cour::findOrFail($id);
        if($request->has('oui')){//================>                            //Si on appui sur OUI...
            $cours->etudiants()->detach();
            $cours->enseignant()->detach();
            $cours->delete();//=====================>                            //...on le supprime
            $request->session()->flash('etat', 'Suppression effectuée !');//===>//avec un message de succes
        }else{
            $request->session()->flash('etat', 'Suppression annulée !');//=====>//Sinon on ne fait rien avec un message d'annulation
        }
        return redirect()->route('listeCours');
    }



    public function ModifyCoursForm($id) {
        $cours = Cour::findOrFail($id);

        return view('cours.ModifyCoursForm', ['cours'=>$cours]);
    }
   
    public function ModifyCours(Request $request,$id) {
        $cours = Cour::findOrFail($id);

        $validated = $request->validate([//========>                            //Application des règles de validations vue en cours
            'intitule' => 'required|alpha|max:40',
            ]);
                                  
        $cours->intitule = $validated['intitule'];   
        $cours->save();//===========================>                            //On sauvegarde les champs modifiés
        $request->session()->flash('etat', 'Modification effectuée !');         //Message de succès de l'action
        return redirect()->route('listeCours');//=====================>          //Redirection vers le tableau
    }
}