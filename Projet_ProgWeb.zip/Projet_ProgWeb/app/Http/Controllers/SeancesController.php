<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Cour;
use App\Models\Etudiant;
use App\Models\Seance;




class SeancesController extends Controller
{
    public function ListeSeance(){
        $seances = DB::table('seances')->get();
        return view('seances.ListeDesSeances',['seances'=>$seances]);
    }


    public function CreateSeancesForm() {//=================>                          //creer une seance dans la table "seances"
        return view('seances.CreateSeancesForm');
    }

    public function CreateSeances(Request $request) {
        $validated = $request->validate([ //=========>                          //On applique les règles de validation vue en cours                  
        'cours' => 'bail|required|alpha',
        'date_debut' => 'bail|required|date',   
        'date_fin' => 'bail|required|date|after:date_debut',      

        
        ]);
        $cours = Cour::where('intitule',$request->cours)->first();
        if(isset($cours->id)){
        $seances = new Seance();//========================>                           //On crée une nouvelle seance
        $seances->cours_id = $cours->id;
        $seances->date_debut = $validated['date_debut'];
        $seances->date_fin = $validated['date_fin'];
    

        $seances->save();//============================>                           //On l'enregistre

        $request->session()->flash('etat', 'Séance crée !');//=====>        //On ajoute un message flash si la création à été effectué

        return redirect()->route('listeSeance');//============>                   //Après cela, on revient a la liste contenant toutes les seances
    }
    return back()->withErrors(['cours'=>"Le cours n'existe pas"]);
}

    public function DeleteSeancesForm($id) {//============>                            //Supprimer une seance dans la table "seances"
        $seances = Seance::findOrFail($id);//=============>                            //On la recherche avec son ID
        return view('seances.DeleteSeancesForm', ['seances'=>$seances]);
    }

    public function DeleteSeances(Request $request,$id) {
        $seances = Seance::findOrFail($id);
        if($request->has('oui')){//================>                            //Si on appui sur OUI...
            $seances->cours()->dissociate();
            $seances->etudiants()->detach();
            $seances->delete();//=====================>                            //...on la supprime
            $request->session()->flash('etat', 'Suppression de la séance effectuée !');//===>//avec un message de succes
        }else{
            $request->session()->flash('etat', 'Suppression de la séance annulée !');//=====>//Sinon on ne fait rien avec un message d'annulation
        }
        return redirect()->route('listeSeance');
    }



    public function ModifySeancesForm($id) {
        $seances = Seance::findOrFail($id);
        return view('seances.ModifySeancesForm', ['seances'=>$seances]);
    }
   
    public function ModifySeances(Request $request,$id) {
        $validated = $request->validate([//========>                            //Application des règles de validations vue en cours
            'cours' => 'bail|required|alpha',
            'date_debut' => 'bail|required|date',   
            'date_fin' => 'bail|required|date',  
            ]);
        
        $cours = Cour::where('intitule',$request->cours)->first();
        if(isset($cours->id)){ 
        $seances = Seance::findOrFail($id);                                 
        $seances->cours_id = $cours->id;
        $seances->date_debut = $validated['date_debut']; 
        $seances->date_fin = $validated['date_fin'];    
        $seances->save();//===========================>                            //On sauvegarde les champs modifiés
        $request->session()->flash('etat', 'Modification de la séance effectuée !');         //Message de succès de l'action
        return redirect()->route('listeSeance');//=====================>          //Redirection vers la liste
    }
    return back()->withErrors(['cours'=>"Le cours n'existe pas"]);
}


}