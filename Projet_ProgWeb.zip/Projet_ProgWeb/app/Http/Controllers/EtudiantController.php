<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Cour;
use App\Models\Etudiant;



class EtudiantController extends Controller
{
    public function ListeEtudiant(){
        $etudiants = DB::table('etudiants')->get();
        return view('etudiants.ListeDesEtudiants',['etudiants'=>$etudiants]);
    }


    public function CreateEtudiantsForm() {//=================>                          //Ajouter un etudiant dans la table "etudiants"
        return view('etudiants.CreateEtudiantsForm');
    }

    public function CreateEtudiants(Request $request) {
        $validated = $request->validate([ //=========>                          //On applique les règles de validation vue en cours                 
        'nom' => 'required|alpha|max:40',     
        'prenom' => 'required|alpha|max:40', 
        'noet' => 'bail|required|integer|gte:0|lte:99999999',                   
        
        ]);
    
        $etudiants = new Etudiant();//========================>                           //On crée un nouveau etudiant
        $etudiants->nom = $validated['nom'];
        $etudiants->prenom = $validated['prenom'];
        $etudiants->noet = $validated['noet'];
        

        $etudiants->save();//============================>                           //On l'enregistre

        $request->session()->flash('etat', 'Etudiant(e) Ajouté(e) !');//=====>        //On ajoute un message flash si la création à été effectué

        return redirect()->route('listeEtudiants');//============>                   //Après cela, on revient a la liste contenant tous les etudiaants
    }

    public function DeleteEtudiantsForm($id) {//============>                            //Supprimer un etudiant dans la table "etudiants"
        $etudiants = Etudiant::findOrFail($id);//=============>                            //On le recherche avec son ID
        return view('etudiants.DeleteEtudiantsForm', ['etudiants'=>$etudiants]);
    }

    public function DeleteEtudiants(Request $request,$id) {
        $etudiants = Etudiant::findOrFail($id);
        if($request->has('oui')){//================>                            //Si on appui sur OUI...
            $etudiants->cours()->detach();
            $etudiants->seances()->detach();
            $etudiants->delete();//=====================>                            //...on le supprime
            $request->session()->flash('etat', 'Suppression effectuée !');//===>//avec un message de succes
        }else{
            $request->session()->flash('etat', 'Suppression annulée !');//=====>//Sinon on ne fait rien avec un message d'annulation
        }
        return redirect()->route('listeEtudiants');
    }



    public function ModifyEtudiantsForm($id) {
        $etudiants = Etudiant::findOrFail($id);
        return view('etudiants.ModifyEtudiantsForm', ['etudiants'=>$etudiants]);
    }
   
    public function ModifyEtudiants(Request $request,$id) {
        $validated = $request->validate([//========>                            //Application des règles de validations vue en cours
            'nom' => 'required|alpha|max:40',
            'prenom' => 'required|alpha|max:40',
            'noet' => 'bail|required|integer|gte:0|lte:99999999',
            ]);
        $etudiants = Etudiant::findOrFail($id);                                  
        $etudiants->nom = $validated['nom'];
        $etudiants->prenom = $validated['prenom']; 
        $etudiants->noet = $validated['noet'];    
        $etudiants->save();//===========================>                            //On sauvegarde les champs modifiés
        $request->session()->flash('etat', 'Modification effectuée !');         //Message de succès de l'action
        return redirect()->route('listeEtudiants');//=====================>          //Redirection vers la  liste
    }
    
}