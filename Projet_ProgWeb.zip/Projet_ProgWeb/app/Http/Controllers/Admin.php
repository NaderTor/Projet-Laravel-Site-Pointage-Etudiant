<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;



class Admin extends Controller
{
    //fonction qui renvoie la liste des utilisateurs
    public function listUtilisateur(){
        $users = DB::table('users')->get();
        return view('user.usersListe',['users'=>$users]);
    }

    //fonction qui renvoie la liste des utilisateurs enseignant
    public function listUtilisateurEnseignant(){
        $users = DB::table('users')->get();
        return view('user.EnseignantListe',['users'=>$users]);
    }

    //fonction qui renvoie la liste des utilisateurs gestionnaire
    public function listUtilisateurGestionnaire(){
        $users = DB::table('users')->get();
        return view('user.GestionnaireListe',['users'=>$users]);
    }
   
    //fonction qui renvoie le formulaire pour créer un compte enseignant
    public function creationEnseignantForm(){
        return view('user.CreationEnseignantForm');

    }
    //fonction qui crée le compte enseignant
    public function creationEnseignant(Request $request){
        $request ->validate(
            [
                'nom'=>'required|string|max:30',
                'prenom'=>'required|string|max:30',
                'login'=>'required|string|max:30|unique:users',
                'mdp'=>'required|string|confirmed'
            ]
        );
        $user = new User();
        $user ->nom = $request->nom;
        $user ->prenom = $request->prenom;
        $user ->login = $request->login;
        $user ->mdp = Hash::make($request->mdp);

            $user ->type="enseignant";
            $user ->save();

            return redirect(route('ListUsers'))->with('etat','Un compte enseignant a été crée !');

    }

    //fonction qui renvoie le formulaire pour créer un compte gestionnaire
    public function creationGestionnaireForm(){
        return view('user.CreationGestionnaireForm');

    }

    //fonction qui crée le compte gestionnaire
   public function creationgestionnaire(Request $request){
        $request ->validate(
            [
                'nom'=>'required|string|max:30',
                'prenom'=>'required|string|max:30',
                'login'=>'required|string|max:30|unique:users',
                'mdp'=>'required|string|confirmed'
            ]
        );
        $user = new User();
        $user ->nom = $request->nom;
        $user ->prenom = $request->prenom;
        $user ->login = $request->login;
        $user ->mdp = Hash::make($request->mdp);

           $user ->type="gestionnaire";
           $user ->save();

           return redirect(route('ListUsers'))->with('etat','Un compte gestionnaire a été crée !');
       }

    //fonction qui renvoie le formulaire pour supprimer un utilisateur
    public function deleteFormUser($id){

        $user = User::findOrFail($id);
        return view('user.deleteFormUser',['user'=>$user]);
    }
    //fonction qui supprime un utilisateur
    public function delete(Request $request,$id){
        $user = User::findOrFail($id);
        if($request->has('oui')){
            $user->delete();
            $request->session()->flash('etat', 'Suppression effectuée !');
        }else{
            $request->session()->flash('etat', 'Suppression annulée !');
        }
        return redirect()->route('ListUsers');
    }
    //fonction qui renvoie le formulaire pour modifier le type d'un utilisateur
    public function modifyTypeForm($id){
        $user = User::findOrFail($id);
        return view('user.modifytypeForm',['user'=>$user]);
    }
    //fonction qui modifie le type d'un utilisateur
    public function modifyType(Request $request,$id){
        $validated = $request->validate([
            'type' => 'required|string|Max:20',
           ]);

        $user = User::findOrFail($id);
        $user -> type = $validated['type'];
        $user->save();
        $request->session()->flash('etat', 'Modification effectué !');
    return redirect()->route('ListUsers');
    }
    //fonction qui renvoie le formulaire pour modifier le nom/prenom d'un utilisateur
    public function modifyInfoForm(){
        $user = AUTH::user();
        return view('user.modifyinfoForm',['user'=>$user]);
    }
     //fonction qui modifie le nom/prenom d'un utilisateur
    public function modifyInfo(Request $request){
        $user = AUTH::user();

        $validated = $request->validate([
            'nom' => 'required|string|Max:40',
            'prenom' => 'required|string|Max:40',
           ]);

        $user -> nom = $validated['nom'];
        $user -> prenom = $validated['prenom'];
        $user->save();
        $request->session()->flash('etat', 'Modification effectué !');
    return redirect()->route('pageacceuil');
    }
    //fonction qui renvoie le formulaire pour modifier un utilisateur
    public function modifyUserForm($id){
        $user = User::FindOrFail($id);
        return view('user.modifyUserForm',['user'=>$user]);
    }
    //fonction qui modifie un utilisateur
    public function modifyUser(Request $request,$id){
        $user = User::findOrFail($id);
        $validated = $request->validate([
            'nom' => 'required|string|Max:40',
            'prenom' => 'required|string|Max:40',
            'login'=>'required|string|max:30|unique:users',
            'mdp'=>'required|string|confirmed',
            'type' => 'required|string|Max:20',
           ]);

        $user -> nom = $validated['nom'];
        $user -> prenom = $validated['prenom'];
        $user -> login = $validated['login'];
        $user->mdp = Hash::make($request->mdp);
        $user -> type = $validated['type'];
        $user->save();
        $request->session()->flash('etat', 'Modification effectué !');
    return redirect()->route('ListUsers');
    }

    
}

