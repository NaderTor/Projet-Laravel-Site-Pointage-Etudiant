<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class RegisterUserController extends Controller
{
    //fonction qui renvoie le formulaire d'enregistrement
    public function create(){
        return view('auth.register');
    }
    //fonction qui permet l'enregistrement
    public function store(Request $request){
        $request->validate([
            'login' => 'required|string|max:255|unique:users',
            'mdp' => 'required|string|confirmed'//|min:8',
        ]);

        $users = new User();
        $users = User::create($request->only(['nom','prenom','login', 'mdp']));
        $users->nom = $request->nom;
        $users->prenom = $request->prenom;
        $users->login = $request->login;
        $users->mdp = Hash::make($request->mdp);
        $users->save();
   
        $request->session()->flash('etat','Veuillez patientez que le gérant vous accepte');
 
        

        return view('pageacceuil');
    }
}
