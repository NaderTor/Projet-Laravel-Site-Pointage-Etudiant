<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Cour;
use App\Models\Etudiant;
use App\Models\Seance;


class EnseignantController extends Controller
{

    //fonction qui renvoie la liste des cours associe à un en enseignant
    public function ListeCoursEnseignant(Request $request){
        $enseignant = AUTH::user();
        $cours = $enseignant->cours()->get();
        return view('Enseignant.ListeCoursEnseignant',['enseignants'=>$cours]);
    }

    public function listePresenceAssociation(){
        $associations = DB::table('presences')->get();
        return view('InscriptionEnseignant.ListeAssociationEnseignant',['associations'=>$associations]);
    }

    //fonction qui renvoie des séance par cours
    public function ListeSeanceByCours(Request $request){
        $cours = Cour::find($request->cours_id);
        $seances = $cours->seances;
        return view('Enseignant.ListeSeanceParCours',['seances'=>$seances]);
    }


    //fonction qui renvoie le formulaire du pointage
    public function PointageForm(Request $request){
        $seances = Seance::findOrFail($request->seance_id);
        $cours = $seances->cours;
        $etudiants = $cours->etudiants;
        return view('Enseignant.PointageForm',['seance'=>$seances,'etudiants'=>$etudiants]);

    }
    //fonction qui permet de pointer les etudiants
    public function Pointage(Request $request){
        $seances = Seance::find($request->seance_id);
        
            foreach($request->pointage as $etudiant_id){
                $e = $seances->etudiants()->find($etudiant_id);
                if(!isset($e)){
                    $etudiants = Etudiant::find($etudiant_id);
                    $seances->etudiants()->attach($etudiants);
                }
            }
        
        $request->session()->flash('etat','Pointage effectuer');
        return redirect()->route('pageEnseignant');
    }
    
    //fonction qui renvoie la liste des etudiants pointés pour la séance
    public function ListePresence(Request $request){
        $seances = Seance::find($request->seance_id);
        $presences = $seances->etudiants;
        return view('Enseignant.ListeDesPresences',['presences'=>$presences]);
    }




}