<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Cour;
use App\Models\Etudiant;


class AssociationCourEnseignant extends Controller
{
    //fonction qui renvoie la liste des associations Cours/enseignant
    public function listeCourEnseignant(){
        $associations = DB::table('cours_users')->get();
        return view('InscriptionEnseignant.ListeAssociationEnseignant',['associations'=>$associations]);
    }
    //fonction qui renvoie la liste des enseignants inscrit à un cours
    public function EnseignantInscrit(Request $request){

        $c = Cour::where('id',$request->id)->first();
        $enseignant = $c->enseignant()->get();
        return view('cours.ListeEnseignantInscrit',['associations'=>$enseignant]);
    }
    //fonction qui renvoie le formulaire des associations Cours/enseignant
    public function AssociationEnseignantForm() {
        return view('InscriptionEnseignant.CreateAssociationForm');
    }

    //fonction qui associe un enseignant à un cours
    public function AssociationEnseignant(Request $request){
        $validated = $request->validate([
            'cours' => 'bail|required|alpha',
            'enseignant' => 'bail|required|alpha',
        ]);

        $enseignant = User::where('nom',$request->enseignant)->first();
        $cours = Cour::where('intitule',$request->cours)->first();

        if($enseignant->type=='enseignant'){
        if(isset($cours->id)){
            
            $cours->cours_id = $cours->id;
            $enseignant->user_id = $enseignant->id;
            $enseignant->cours()->attach($cours);
            

        $request->session()->flash('etat', 'Association effectuée !');
        return redirect()->route('ListeCoursEnseignant');

    }
}
    return back()->withErrors(['association'=>"Cet enseignant n'existe pas et/ou ce cours n'existe pas "]);
}
//fonction qui renvoie le formulaire de dissociation Cours/enseignant
public function DissociateEnseignantForm($cours_id,$user_id) {
    return view('InscriptionEnseignant.DissociateEnseignantForm', ['cours_id' => $cours_id, 'user_id' => $user_id]);
}
//fonction qui dissocie un enseignant à un cours
public function DissociateEnseignant(Request $request,$cours_id,$user_id){
    $enseignant = User::findOrFail($user_id);
    $cours = Cour::findOrFail($cours_id);


    $enseignant->cours()->detach($cours);
    
    $request->session()->flash('etat', 'Dissociation effectuée !');
    return redirect()->route('ListeCoursEnseignant');

}


}