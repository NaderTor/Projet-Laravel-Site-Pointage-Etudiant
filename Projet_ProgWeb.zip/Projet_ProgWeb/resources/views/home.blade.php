@extends('pageacceuil')

@section('contents')
    <p>Page d'accueil.</p>

   
@endsection