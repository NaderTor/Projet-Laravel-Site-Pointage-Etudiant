<!------------------------------------------------------PAGE CONTENANT LA LISTE DES ASSOCIATIONS ENSEIGNANT/COURS--------------------------------->


@extends('pageacceuil')


@section('contents')

<style>
table,
    th,
    td {
        padding: 9px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }
    .AjouAssoEns{
        background-color: blue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }

      .SuppAssoEns{
        background-color: red;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      .retour{
     background-color: green;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
}
</style>

<table>
        <th>Cours_Id</th>
        <th>User_ID</th>

@foreach ($associations as $association)
<tr><td> {{ $association->cours_id }}</td> <td> {{ $association->user_id }}</td><td>
<a href="{{route('dissociateEnseignantForm', ['cours_id' => $association->cours_id , 'user_id' => $association->user_id])}}" class="SuppAssoEns">supprimer une association</a></td>
</tr>
   
@endforeach
    </table> 
        <center>
            <p><a href="{{route('associationEnseignantForm')}}" class="AjouAssoEns">Ajouter une association </a></p>
            <p><a href="{{route('pageacceuil')}}" class="retour">Retourner à l'acceuil</a></p>
            <p>Allez dans la liste des cours puis dans "Liste Enseignant associé" pour voir que l'association à été effectuer</p>
        </center>
@endsection