<!------------------------------------------------------PAGE CONTENANT LA LISTE DE TOUS LES UTILISATEURS--------------------------------------------------->


@extends('pageacceuil')

@section('title','Liste des Utilisateurs')

@section('contents')
    <center><legend>Liste des utilisateurs</legend></center>
    <a href="{{route('pageacceuil')}}"><button name="acceuil"><span>Retour à l'accueil</span></button></a>
    <style>
    
       table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }
      button {
        display: inline-block;
        background-color: #7b38d8;
        border-radius: 10px;
        border: 4px double #cccccc;
        color: #eeeeee;
        text-align: center;
        font-size: 15px;
        padding: 10px;
        width: 150px;
        transition: all 0.5s;
        cursor: pointer;
        margin: 5px;
        margin-left:auto;
        margin-right:auto;
      }
      button span {
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;
      }
      button span:after {
        content: "\00bb";
        position: absolute;
        opacity: 0;
        top: 0;
        right: -20px;
        transition: 0.5s;
      }
      button:hover {
        background-color: #f7c2f9;
      }
      button:hover span {
        padding-right: 5px;
      }
      button:hover span:after {
        opacity: 1;
        right: 0;
      }
    </style>
    
    <table>
        <th>Id</th>
        <th>Nom</th>
        <th>Penom</th>
        <th>Login</th>
        <th>Type</th>
        @foreach($users as $user)
            <tr>
            <td>{{$user->id}}</td>
            <td>{{$user->nom}}</td>
            <td>{{$user->prenom}}</td>
            <td>{{$user->login}}</td>
            <td>{{$user->type}}</td>
            <td><a href="{{route('DeleteFormUser',['id'=>$user->id])}}"><button class = 'suppUser'> <span>Supprimer </span></button></a></td>
            <td><a href = "{{route('MofifyTypeForm',['id'=>$user->id])}}"><button class = 'acceptUser'><span>Acceptation</span></button></a></td>
            <td><a href = "{{route('ModifyUserForm',['id'=>$user->id])}}"><button class = "modUser"> <span>Modifier l'utilisateur </span></button></a></td>
            </tr>
        @endforeach
        <center>
        <a href="{{route('CreateEnseignantForm')}}"><button class="creeEns"><span>Créer un utilisateur enseignant</span></button>
        <a href="{{route('CreateGestionnaireForm')}}"><button class="creeGes"><span>Créer un utilisateur gestionnaire</span></button>
        <a href="{{route('ListUtilisateurGestionnaire')}}"><button class="voirGes"><span>Voir les utilisateurs gestionnaire</span></button>        <a href="{{route('CreateGestionnaireForm')}}"><button class="creeGes"><span>Créer un utilisateur gestionnaire</span></button>
        <a href="{{route('ListUtilisateurEnseignant')}}"><button class="voirEns"><span>Voir les utilisateurs enseignant</span></button>
        </center>

        </table>
@endsection
