<!------------------------------------------------------PAGE CONTENANT LE FORMULAIRE DE CREATION D'UN UTILISATEUR ENSEIGNANT--------------------------------------->


@extends('PageAcceuil')

@section('contents')
   
<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<form class="bg-light p-3 w-50 m-3" action="{{route('CreationEnseignant')}}" method="post">
			<legend> Créez un Utilisateur Enseignant </legend>
			<div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Nom </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="nom" value="{{old('nom')}}">
				</div>
			</div>
			<div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Prénom </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="prenom" value="{{old('prenom')}}">
				</div>
			</div>
			<div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Login </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="login" value="{{old('login')}}">
				</div>
			</div>
            <div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Mot-De-Passe </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="password" class="form-control" id="inputNom" style="width:93.5%" name="mdp">
				</div>
			</div>
            <div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Confirmation du Mot-De-Passe </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="password" class="form-control" id="inputNom" style="width:93.5%" name="mdp_confirmation">
				</div>
			</div>
        <button type="submit" class="btn btn-primary col-4 mt-3" style="padding:10px; font-size:20px" value="Envoyer">Envoyer</button>
        @csrf
</form>
@endsection
