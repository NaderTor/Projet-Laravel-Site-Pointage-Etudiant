@extends('pageacceuil')

@section('title','Les Utilisateurs Gestionnaire')
       <style>
          table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }  
       </style>

@section('contents')
    <h3>Liste des utilisateurs GESTIONNAIRE</h3>
    <table>
        <th>ID</th>
        <th>Nom</th>
        <th>Prenom</th>
        <th>Login</th>
        @foreach($users as $user)
            @if($user ->type!="admin" && $user ->type!="enseignant")
                <tr>
                    <td>{{$user->id}}</td><td>{{$user->nom}}</td><td>{{$user->prenom}}</td><td>{{$user->login}}</td>
                </tr>
            @endif
        @endforeach

    </table>

@endsection