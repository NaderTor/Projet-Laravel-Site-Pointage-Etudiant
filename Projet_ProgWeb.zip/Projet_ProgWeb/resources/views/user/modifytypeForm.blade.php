<!------------------------------------------------------PAGE CONTENANT LE FORMULAIRE DE MODIFICATION DU TYPE D'UN UTILISATEUR--------------------------------------->


@extends('PageAcceuil')

@section('title','Acceptation Utilisateurs')

@section('contents')
    <meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <legend>Si vous souhaitez accepter l'utilisateur {{$user->login}}, vous pouvez lui attribuer son type voulu lors de l'enregistrement.</legend>
    <form action="{{route('ModifyType',['id'=>$user->id])}}" method="post" class="bg-light p-3 w-50 m-3">
        
        <div class="champ">
				<label for="type" class="col-1 col-form-label"> Type: </label>
                <select id="type" name="type" value="{{$user->type}}">
                <optgroup label="Type">
                    <option value="enseignant">Enseignant</option>
                    <option value="gestionnaire">Gestionnaire</option>
                    </select>
			</div>
        <button type="submit" class="btn btn-primary col-2 mt-3" style="padding:5px; font-size:20px" name="envoyer" value="Envoyer">Envoyer</button>
        <button style="padding:5px; font-size:20px" class="btn btn-primary col-2 mt-3" ><a href="{{route('ListUsers')}}" type="submit" value="Annuler" style="color: black ;text-decoration: none;width: 70px">Annuler</a></button>
        @csrf
    </form>
@endsection





