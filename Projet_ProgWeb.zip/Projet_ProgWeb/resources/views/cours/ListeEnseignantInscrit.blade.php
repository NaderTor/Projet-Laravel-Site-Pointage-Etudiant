<!------------------------------------------------------PAGE CONTENANT LA LISTE DES ENSEIGNANTS ASSOCIE A UN COURS--------------------------------------->


@extends('pageacceuil')


@section('contents')

<style>
    
    table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }
    th {
        color: blue;
        background-color: lightgrey;
    }
</style>

<table>
        <th>Id</th>
        <th>Nom</th>
        <th>Prenom</th>
        <th>Login</th>

@foreach ($associations as $enseignant)
<tr><td> {{ $enseignant->id }}</td> <td> {{ $enseignant->nom }}</td> <td>{{ $enseignant->prenom }}</td> <td>{{ $enseignant->login }}</td>
@endforeach

</table> 

@endsection