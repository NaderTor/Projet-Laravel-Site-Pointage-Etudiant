<!------------------------------------------------------PAGE CONTENANT LA LISTE DES ETUDIANT ASSOCIE A UN COURS--------------------------------------->


@extends('pageacceuil')


@section('contents')


<style>
    table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }
    th {
        color: blue;
        background-color: lightgrey;
    }
</style>

<table>
        <th>Id</th>
        <th>Nom</th>
        <th>Prenom</th>
        <th>N°étudiant</th>
        
@foreach ($associations as $etudiant)
<tr><td> {{ $etudiant->id }}</td> <td> {{ $etudiant->nom }}</td> <td>{{ $etudiant->prenom }}</td> <td>{{ $etudiant->noet }}</td>
@endforeach

</table> 
@endsection