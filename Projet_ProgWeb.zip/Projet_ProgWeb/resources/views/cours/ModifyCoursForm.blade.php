<!------------------------------------------------------PAGE CONTENANT LE FORMULAIRE DE MODIFICATION D'UN COURS--------------------------------------->


@extends('pageacceuil')


@section('contents')

<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<form class="bg-light p-3 w-50 m-3" action="{{route('modifyCours',['id'=>$cours->id])}}" method="post">
			<legend> Modification d'un cours </legend>
            <p>Vous pouvez modifier le cours de {{$cours->intitule}}</p>
			<div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Intitulé </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputNom" style="width:93.5%" name="intitule" value="{{$cours->intitule}}">
				</div>
			</div>
        <button type="submit" class="btn btn-primary col-4 mt-3" style="padding:10px; font-size:20px" value="Envoyer">Envoyer</button>
		<button style="padding-left: 10px;margin-top: 5px;"><a href="{{route('listeCours')}}" type="submit" value="Annuler" style="color: black ;text-decoration: none;width: 70px">Annuler</a></button>
        @csrf
        @csrf
</form>
@endsection


