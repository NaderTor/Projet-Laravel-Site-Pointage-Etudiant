<!------------------------------------------------------PAGE CONTENANT LA LISTE DES COURS ASSOCIE A UN ENSEIGNANT--------------------------------->


@extends('pageacceuil')

@section('contents')

<style>
    table,
    th,
    td {
        padding: 9px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }
    .SeanCour{
    background-color: purple;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
}
 .retour{
    background-color: orange;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
}

</style>


<table>
        <th>Id</th>
        <th>Intitulé</th>
        <th>Created_at</th>
        <th>Updated_at</th>

@foreach ($enseignants as $cour)
<tr><td> {{ $cour->id }}</td> <td> {{ $cour->intitule }}</td> <td>{{ $cour->created_at }}</td> <td> {{ $cour->updated_at }}</td>
    <td><a href = "{{route('listeSeanceByCours',['cours_id'=>$cour])}}" class="SeanCour">Liste des seances pour ce cours</a></td>
</tr>
@endforeach
<a href="{{route('pageEnseignant')}}" class="retour">Retourner à la page des enseignant</a>
    </table> 
@endsection