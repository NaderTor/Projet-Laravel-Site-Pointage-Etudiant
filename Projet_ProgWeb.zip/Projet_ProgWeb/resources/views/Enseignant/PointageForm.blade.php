<!------------------------------------------------------PAGE CONTENANT LE FORMULAIRE DE POINTAGE DES ETUDIANTS A UN COURS --------------------------------->



@extends('pageacceuil')

@section('contents')

<style>

    
      .retour {
        background-color: green;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      
</style>
<table>
<form action={{route('pointage',['seance_id'=>$seance->id])}} method="post">
    @foreach ($etudiants as $etudiant)
<input type="checkbox" name="pointage[]" value={{$etudiant->id}}>
<label> {{ $etudiant->id }}{{ $etudiant->nom }}{{$etudiant->prenom }}{{$etudiant->noet }}{{$etudiant->created_at }}{{ $etudiant->updated_at }}</label>
<br>   
@endforeach
    <input type="submit" value="valider">
    @csrf
</form>
</table>
        <center>  
            <p><a href="{{route('listeCoursEnseignant')}}" class="retour">Retourner à la liste des cours de l'Enseignant</a></p>
            <a href="{{route('pageEnseignant')}}" class="retour">Retourner à la page des enseignant</a>
        </center>
@endsection