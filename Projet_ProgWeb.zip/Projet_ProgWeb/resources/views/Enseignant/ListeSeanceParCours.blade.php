<!------------------------------------------------------PAGE CONTENANT LA LISTE DES SEANCES DE CHAQUE COURS-------_----------------------------->


@extends('pageacceuil')


@section('contents')

<center>
<Legend>Liste des Séances pour ce cours</Legend>
</center>

<style>
    
       table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }

    
      
      .retour {
        background-color: green;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      .point {
        background-color: lightblue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }

      .ListPre {
        background-color: lightgrey;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
    
      
      
</style>


<table>
        <th>Id</th>
        <th>Cours_ID</th>
        <th>Date de début</th>
        <th>Date de fin</th>
        

@foreach ($seances as $seance)
<tr><td> {{ $seance->id }}</td> <td> {{ $seance->cours_id }}</td> <td>{{ $seance->date_debut }}</td> <td>{{ $seance->date_fin }}</td><td>
    <a href = {{route('pointageForm',['seance_id'=>$seance->id])}} class="point">Effectuer le pointage</a></td>
    <td><a href = {{route('listePresence',['seance_id'=>$seance->id])}} class="ListPre">Liste Des présents</a></td>
@endforeach
</table> 
        <center>
            <p><a href="{{route('listeCoursEnseignant')}}" class="retour">Retourner à la liste des cours de l'Enseignant</a></p>
            <p><a href="{{route('pageEnseignant')}}" class="retour">Retourner à la page des enseignant</a></p>
        </center>
@endsection