<!------------------------------------------------------PAGE CONTENANT LA PARTIE DES TACHE DES ENSEIGNANTS--------------------------------->


@extends('pageacceuil')

@section('contents')

<style>
.ListCourIns {
        background-color: lightpink;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      .acceuil {
        background-color: lightgreen;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }

</style>
 <p><a href = "{{route('listeCoursEnseignant')}}" class="ListCourIns">Liste des cours inscrit</a></p>
 <p><a href = "{{route('pageacceuil')}}" class="acceuil">Retourner à la l'accueil</a></p>

 @endsection