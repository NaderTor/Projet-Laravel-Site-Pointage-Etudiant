<!------------------------------------------------------PAGE CONTENANT LA LISTE DES ETUDIANTS POINTE DANS UN COURS--------------------------------->


@extends('pageacceuil')

@section('contents')

<style>
   table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }

      .retour {
        background-color: green;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      
</style>
<table>
        <th>Id</th>
        <th>Nom</th>
        <th>Prenom</th>
        <th>N°étudiant</th>
        <th>Created_at</th>
        <th>Updated_at</th>

@foreach ($presences as $etudiant)
<tr><td> {{ $etudiant->id }}</td> <td> {{ $etudiant->nom }}</td> <td>{{ $etudiant->prenom }}</td> <td>{{ $etudiant->noet }}</td>
    
@endforeach
    </table> 
        
            <p><a href="{{route('pageacceuil')}}" class="retour">Retourner à l'acceuil</a></p>
            <p><a href="{{route('listeCoursEnseignant')}}" class="retour">Retourner à la liste des cours de l'Enseignant</a></p>
            <a href="{{route('pageEnseignant')}}" class="retour">Retourner à la page des enseignant</a>
        
@endsection