<!------------------------------------------------------PAGE DE LA SUPPRESSION D'UNE ASSOCIATION D'UN ETUDIANT A UN COOURS--------------------------------->


@extends('PageAcceuil')


@section('title','Dissocier des etudiants')

@section('contents')
    <p>Voulez-vous supprimer cette inscrption ?</p>
    <form action="{{route('dissociateEtudiant',  ['cours_id' => $cours_id , 'etudiant_id' => $etudiant_id])}}" method="post">
        @csrf
        <input type="submit" value="Supprimer">
        <button style="padding-left: 10px;margin-top: 5px;"><a href="{{route('ListeAssociationCourEtudiant')}}" type="submit"
         value="Annuler" style="color: black ;text-decoration: none;width: 70px">Annuler</a></button>

    </form>
@endsection