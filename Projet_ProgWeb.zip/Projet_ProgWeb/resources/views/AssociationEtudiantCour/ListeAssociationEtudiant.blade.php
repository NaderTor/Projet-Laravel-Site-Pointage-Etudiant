<!------------------------------------------------------PAGE CONTENANT LA LISTE DES ASSOCIATIONS ETUDIANT/COURS--------------------------------->

@extends('pageacceuil')

@section('contents')

<center>
    <Legend>Associer des Etudiants à un cours</Legend>

<style>

    table,
    th,
    td {
        padding: 9px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }
    .AjouAsso {
        background-color: blue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
       .SuppAssoEtu {
        background-color: red;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      .retour{
     background-color: green;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 4px 2px;
        cursor: pointer;
}
    </style>
<table>
        <th>Cours_Id</th>
        <th>Etudiant_ID</th>

@foreach ($associations as $association)
<tr><td> {{ $association->cours_id }}</td> <td> {{ $association->etudiant_id }}</td><td>
<a href="{{route('dissociateEtudiantForm',  ['cours_id' => $association->cours_id , 'etudiant_id' => $association->etudiant_id])}}"
 class="SuppAssoEtu">supprimer une association</a></td>
@endforeach
    </table> 
        <center>
            <p><a href="{{route('associationEtudiantForm')}}" class="AjouAsso">Ajouter une association </a></p>
            <p><a href="{{route('pageacceuil')}}" class="retour">Retourner à l'acceuil</a></p>
            <p>Allez dans la liste des cours puis dans "Liste Etudiant associé" pour voir que l'association à été effectuer</p>
        </center>
@endsection