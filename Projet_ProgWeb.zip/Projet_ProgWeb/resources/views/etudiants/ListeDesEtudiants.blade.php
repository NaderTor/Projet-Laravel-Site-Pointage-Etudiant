<!------------------------------------------------------PAGE CONTENANT LA LISTE DES ETUDIANT--------------------------------------------------->


@extends('pageacceuil')

@section('contents')

<style>
   table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }

    .SuppEtu {
        background-color: red;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }

      .ModEtu {
        background-color: yellow;
        border: none;
        color: black;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      .Ajouetu {
        background-color: blue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      .retour {
        background-color: green;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      
</style>
<table>
        <th>Id</th>
        <th>Nom</th>
        <th>Prenom</th>
        <th>N°étudiant</th>
        <th>Created_at</th>
        <th>Updated_at</th>

@foreach ($etudiants as $etudiant)
<tr><td> {{ $etudiant->id }}</td> <td> {{ $etudiant->nom }}</td> <td>{{ $etudiant->prenom }}</td> <td>{{ $etudiant->noet }}</td><td>{{ $etudiant->created_at }}</td><td>{{ $etudiant->updated_at }}</td><td>
    <a href="{{route('deleteEtudiantsForm', ['id'=>$etudiant->id])}}" class="SuppEtu">Supprimer un etudiant</a></td><td>
    <a href="{{route('modifyEtudiantsForm', ['id'=>$etudiant->id])}}" class="ModEtu">Modifier un étudiant</a></td></tr>
@endforeach
    </table> 
        <center>
            <p><a href="{{route('createEtudiantsForm')}}" class="Ajouetu">Ajouter un étudiant</a></p>
            <p><a href="{{route('pageacceuil')}}" class="retour">Retourner à l'acceuil</a></p>
        </center>
@endsection