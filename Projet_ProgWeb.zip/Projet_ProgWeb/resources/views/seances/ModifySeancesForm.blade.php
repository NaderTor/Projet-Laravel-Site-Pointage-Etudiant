<!------------------------------------------------------PAGE CONTENANT LE FORMULAIRE DE MODIFICATION D'UNE SEANCE DE COURS--------------------------------------->


@extends('pageacceuil')

@section('contents')

<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<form class="bg-light p-3 w-50 m-3" action="{{route('modifySeances',['id'=>$seances->id])}}" method="post">
			<legend> Modification de la séance de cours </legend>
			<div class="form-group row mb-0">
				<label for="inputNom" class="col-6 col-form-label"> Cours </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="text" class="form-control" id="inputCours_id" style="width:93.5%" name="cours" value="{{old('cours')}}">
				</div>
			</div>
            <div class="form-group row mb-0">
				<label for="inputDate_debut" class="col-6 col-form-label"> Date_debut </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="datetime-local" class="form-control" id="inputDate_debut" style="width:93.5%" name="date_debut" value="{{$seances->date_debut}}" min="2022-04-23T08:30" max="2022-12-31T11:59">
				</div>
			</div>
            <div class="form-group row mb-0">
				<label for="inputDate_fin" class="col-6 col-form-label"> Date_fin </label>
			</div>
			<div class="form-group row">
				<div class="col-6">
					<input type="datetime-local" class="form-control" id="inputDate_fin" style="width:93.5%" name="date_fin" value="{{$seances->date_fin}}" min="2022-04-23T08:30" max="2022-12-31T11:59">
				</div>
			</div>
        <button type="submit" class="btn btn-primary col-4 mt-3" style="padding:10px; font-size:20px" value="Envoyer">Envoyer</button>
        @csrf
</form>
@endsection