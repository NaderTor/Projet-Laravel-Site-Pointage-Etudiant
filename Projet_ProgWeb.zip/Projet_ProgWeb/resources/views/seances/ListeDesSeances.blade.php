<!------------------------------------------------------PAGE CONTENANT LA LISTE DES SEANCES DE COURS--------------------------------------------------->


@extends('pageacceuil')


@section('contents')

<center>
<Legend>Liste des Séances</Legend>
</center>

<style>
    
       table,
    th,
    td {
        padding: 6px;
        border: 3px solid black;
        border-collapse: collapse;
        margin-left:auto;
        margin-right:auto;
    }

    th {
        color: blue;
        background-color: lightgrey;
    }

    .SuppSean {
        background-color: red;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      .ModSean {
        background-color: yellow;
        border: none;
        color: black;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      .AjouSean {
        background-color: blue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      .retour {
        background-color: green;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }
      
</style>


<table>
        <th>Id</th>
        <th>Cours_ID</th>
        <th>Date de début</th>
        <th>Date de fin</th>
        

@foreach ($seances as $seance)
<tr><td> {{ $seance->id }}</td> <td> {{ $seance->cours_id }}</td> <td>{{ $seance->date_debut }}</td> <td>{{ $seance->date_fin }}</td><td>
    <a href="{{route('deleteSeancesForm', ['id'=>$seance->id])}}" class="SuppSean">Supprimer la séance de cours</a></td><td>
    <a href="{{route('modifySeancesForm', ['id'=>$seance->id])}}" class="ModSean">Modifier la séance de cours</a></td></tr>
@endforeach
</table> 
        <center>
            <p><a href="{{route('createSeancesForm')}}" class="AjouSean">Crée une séance de cours</a></p>
            <p><a href="{{route('pageacceuil')}}" class="retour">Retourner à l'acceuil</a></p>
        </center>
@endsection