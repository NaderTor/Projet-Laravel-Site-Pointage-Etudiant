<!------------------------------------------------------------------PAGE PRINCIPALE----------------------------------------------------------------------->
<!DOCTYPE html>
    <html>
        <head>
            <!-- Required meta tags -->
            <meta charset="utf-8" />
            <title>@yield('title', config('app.name'))</title>
        </head>

        <body>
    @section('menu')

    
<style>
.MODMDP, .MODNP{
        background-color: blue;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
      }

.ListUser{
    background-color: red;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
}

.ListCours, .ListEtudiants, .ListSeances, .AssoEnse, .AssoEtud{
     background-color: grey;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer;
}

.CoteEnse{
   background-color: black;
        border: none;
        color: white;
        padding: 10px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        margin: 3px 2px;
        cursor: pointer; 
}

p{
    font-size: large;
    font-weight: bold;
}

a.LG, a.RE, a.LO{
text-decoration: none;
padding: 10px 30px;
background-color: blue; 
color: white;
border: 1px solid gray;
border-style:inset;
}

a.LG3, a.RE3, a.LO3{
    border-radi
us: 12px;
border: 2px solid #46a28d;
}

a.LG:hover, a.RE:hover, a.LO:hover{
    background-color: yellow;
color:red;
}
</style>





@guest()

    <center>
        <p><Legend>Bienvenue au site de gestion des étudiants</Legend></p>

        <a href="{{route('login')}}" class="LG LG3">Login</a>
        <a href="{{route('register')}}" class="RE RE3 ">Enregistrement</a>
    </center
@endguest

        @section('contents')
        @auth
            <a href="{{route('logout')}}" class="LO LO3">Deconnexion</a>
            <p>Bonjour {{Auth::user()->login}}</p>

            <p>Changer les informations de l'utilisateur connecté:</p>
            <a href = "{{route('modifierForm')}}" class="MODMDP">Changer le mot de passe</a>
            <a href = "{{route('MofifyInfoForm')}}" class="MODNP">Modification Nom/Prenom</a>

            <p>Partie Admin:</p>
            <a href = "{{route('ListUsers')}}" class="ListUser">Liste des utilisateurs</a> 
            
            <p>Partie Admin et Gestionnaire: </p>
            <a href = "{{route('listeCours')}}" class="ListCours">Voir la liste des cours</a>
            <a href = "{{route('listeEtudiants')}}" class="ListEtudiants">Voir la liste des étudiants</a>
            <a href = "{{route('listeSeance')}}" class="ListSeances">Voir la liste des séances</a>
            <a href = "{{route('ListeAssociationCourEtudiant')}}" class="AssoEtud">Inscription Etudiant-->Cours</a>
            <a href = "{{route('ListeCoursEnseignant')}}" class="AssoEnse">Inscription Enseignant-->Cours</a>

            <p>Partie Admin et Enseignant: </p>
            <a href = "{{route('pageEnseignant')}}" class="CoteEnse" >Partie Enseignant</a>
        @endauth
        @endsection

    @show
    @section('etat')
        @if(session()->has('etat'))
            <p class="etat">{{session()->get('etat')}}</p>
        @endif
    @show
    @section('errors')
        @if ($errors->any())
            <div class="error">
                <ul>
                    @foreach ($errors->all() as $error )
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @show
        @yield('contents')
    </body>
</html>

    